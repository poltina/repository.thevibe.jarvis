# script.cdartmanager
cdART Manager for Kodi enriches your music collection with several types of fanart provided by fanart.tv.

If you want to install this release manually via ZIP file then make sure to remove all previous versions via Kodi's Addon-Manager beforehand.

Diskussion available at: http://forum.kodi.tv/showthread.php?tid=77031&action=lastpost

