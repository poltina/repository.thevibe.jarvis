from bs4 import BeautifulSoup
from channel import Channel
from podcast import Podcast
import requests
import config
import os.path


cache = {}

def get_channels():
    """
    Returns all channels
    :return: Array of channel objects
    """
    if cache.has_key('channels'):
        return cache['channels']

    data = []
    html = requests.get('{0}/homepage.aspx'.format(config.BASE_URL))
    soup = BeautifulSoup(html.content, 'html.parser')
    for item in soup.find(id='dtListChanels').find_all('a'):
        c = Channel(item.get_text(), item.get('href'))
        data.append(c)

    cache['channels'] = data
    return data


def get_podcasts_pages(url):
    """
    Returns channel's podcasts pagination links
    :param url: Channel url
    :return: Array of urls
    """
    data = []
    html = requests.get(url)
    soup = BeautifulSoup(html.content, 'html.parser')
    links = soup.select('.PagingText a')
    for i in range(1, len(links) - 1):
        data.append(links[i].get('href'))
    return data


def get_podcasts(url):
    """
    Returns array of channel's podcasts
    :param url: Channel page url
    :return: Array of podcast objects
    """
    if cache.has_key('podcasts') and cache['podcasts'].has_key('url'):
        return cache['podcasts'][url]

    data = []
    html = requests.get(url)
    soup = BeautifulSoup(html.content, 'html.parser')
    for item in soup.select('td[id$=tdPodcastsList] a.TextBold'):
        if item.find('img'):
            image = item.find('img').get('src')
            if not any(x.image == image for x in data):
                text = item.parent.parent.select('table a')
                name = text[0].get_text()
                url = text[0].get('href')
                description = text[1].get_text()
                p = Podcast(name, image, url, description)
                data.append(p)

    cache['podcasts'] = {}
    cache['podcasts'][url] = data
    return data


def get_podcast(pid):
    """
    Returns podcast's RSS as soup object
    :param pid: Podcast ID number
    :return: soup object
    """
    rss = requests.get('{0}/Rss.aspx?ID={1}'.format(config.BASE_URL, str(pid)))
    return BeautifulSoup(rss.content, 'html.parser')


def get_channel_fanart(addon_id, channel_id):
    """
    Returns the channel's fanart path or to a default fanart
    :param addon_id: Addon id
    :param channel_id: Channel id
    :return: Image path
    """
    bg_image = (config.MEDIA_PATH + '/fanart/{1}.jpg').format(config.ADDON_ID, str(channel_id))
    # if not os.path.isfile(bg_image):
    #     bg_image = (config.MEDIA_PATH + '/fanart/default.jpg').format(config.ADDON_ID)
    return bg_image